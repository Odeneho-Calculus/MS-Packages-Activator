--------------------------------------
How to use this product
--------------------------------------
[1] Extract Ms Activator Pro to any destination of your choice.
[2] Open the extracted files
[3] Click on "WinOff_Activator_Pro.exe" to start activating you product.
[Note] If any error, disable any antivirus u are using then start the process again.

[Enjoy Your product]